import torch
import torch.nn as nn
import torch.optim as optim
import sentencepiece as spm
import matplotlib.pyplot as plt
import numpy as np
from transformers import AutoTokenizer, AutoModelForSequenceClassification, pipeline

from config import *
from plant_hormone_network import PlantHormoneNetwork

en_model = "distilbert-base-uncased-finetuned-sst-2-english"
en_tokenizer = AutoTokenizer.from_pretrained(en_model)
en_sentiment = AutoModelForSequenceClassification.from_pretrained(en_model)
en_classifier = pipeline("sentiment-analysis", model=en_sentiment, tokenizer=en_tokenizer)

from deep_translator import GoogleTranslator

# --- Tokenizer ---
sp = spm.SentencePieceProcessor()
sp.load("cz_spm.model")

VOCAB_SIZE = sp.get_piece_size()
PAD_ID = sp.piece_to_id("<PAD>")
BOS_ID = sp.piece_to_id("<BOS>")
EOS_ID = sp.piece_to_id("<EOS>")
UNK_ID = sp.unk_id()

def encode(text):
    return sp.encode(text, out_type=int)

def decode(indices):
    return sp.decode(indices)

# --- Sentiment analysis ---

def get_sentiment_score(text):
    try:
        # translated = GoogleTranslator(source='cs', target='en').translate(text) #uncomment for czech or other languagues (change 'cs')
        # result = en_classifier(translated)[0] #uncomment for czech
        # score = result['score'] #uncomment for czech
        score = text['score'] #comment for czech
        
        # if result['label'] == 'NEGATIVE': #uncomment for czech
        if text['label'] == 'NEGATIVE': #comment for czech
            score = -score
        return float(score)
        #return 0.0
    except Exception as e:
        print(f"Translation/sentiment failed: {e}")
        return 0.0

# --- Positional Encoding ---
class PositionalEncoding(nn.Module):
    def __init__(self, d_model, dropout=0.1, max_len=5000):
        super().__init__()
        self.dropout = nn.Dropout(dropout)
        pe = torch.zeros(max_len, d_model)
        position = torch.arange(0, max_len, dtype=torch.float).unsqueeze(1)
        div_term = torch.exp(torch.arange(0, d_model, 2).float() * (-torch.log(torch.tensor(10000.0)) / d_model))
        pe[:, 0::2] = torch.sin(position * div_term)
        pe[:, 1::2] = torch.cos(position * div_term)
        pe = pe.unsqueeze(0)
        self.register_buffer('pe', pe)

    def forward(self, x):
        x = x + self.pe[:, :x.size(1), :]
        return self.dropout(x)

# --- Biochemical MultiHead Attention ---
class ModulatedMultiHeadAttention(nn.Module):
    def __init__(self, embed_dim, num_heads, dropout=0.1):
        super().__init__()
        self.embed_dim = embed_dim
        self.num_heads = num_heads
        self.dropout = nn.Dropout(dropout)
        assert embed_dim % num_heads == 0
        self.head_dim = embed_dim // num_heads
        self.W_q = nn.Linear(embed_dim, embed_dim)
        self.W_k = nn.Linear(embed_dim, embed_dim)
        self.W_v = nn.Linear(embed_dim, embed_dim)
        self.out_proj = nn.Linear(embed_dim, embed_dim)

    def forward(self, x, plant_signals, return_attn=False):
        B, T, D = x.shape
        q = self.W_q(x).view(B, T, self.num_heads, self.head_dim).transpose(1,2)
        k = self.W_k(x).view(B, T, self.num_heads, self.head_dim).transpose(1,2)
        v = self.W_v(x).view(B, T, self.num_heads, self.head_dim).transpose(1,2)
        attn_scores = torch.matmul(q, k.transpose(-2, -1)) / (self.head_dim ** 0.5)

        # --- MODULATION ---
        dopamine = plant_signals['dopamine']
        serotonin = plant_signals['serotonin']
        cortisol = plant_signals['cortisol']
        oxytocin = plant_signals['oxytocin']

        attn_scores = attn_scores * dopamine
        attn_scores = attn_scores + (serotonin - 1.0)
        attn_scores = attn_scores + torch.randn_like(attn_scores) * (cortisol - 1.0)
        mean_scores = attn_scores.mean(dim=1, keepdim=True)
        attn_scores = attn_scores * (1 - oxytocin) + mean_scores * oxytocin

        attn_weights = torch.softmax(attn_scores, dim=-1)
        attn_output = torch.matmul(attn_weights, v)
        attn_output = attn_output.transpose(1,2).contiguous().view(B, T, D)
        out = self.out_proj(attn_output)
        if return_attn:
            return out, attn_weights
        else:
            return out, None

# --- Plant Transformer Encoder Layer ---
class PlantTransformerBlock(nn.Module):
    def __init__(self, embed_dim, num_heads, ff_dim, dropout):
        super().__init__()
        self.self_attn = ModulatedMultiHeadAttention(embed_dim, num_heads, dropout)
        self.linear1 = nn.Linear(embed_dim, ff_dim)
        self.dropout = nn.Dropout(dropout)
        self.linear2 = nn.Linear(ff_dim, embed_dim)
        self.norm1 = nn.LayerNorm(embed_dim)
        self.norm2 = nn.LayerNorm(embed_dim)
        self.activation = nn.ReLU()

    def forward(self, x, plant_signals, return_attn=False):
        x2, attn = self.self_attn(x, plant_signals, return_attn=return_attn)
        x = x + self.dropout(x2)
        x = self.norm1(x)
        x2 = self.linear2(self.dropout(self.activation(self.linear1(x))))
        x = x + self.dropout(x2)
        x = self.norm2(x)
        if return_attn:
            return x, attn
        else:
            return x, None

# --- PlantTransformerLM ---
class PlantTransformerLM(nn.Module):
    def __init__(self, vocab_size, embed_dim, nhead, num_layers, ff_dim, dropout):
        super().__init__()
        self.embedding = nn.Embedding(vocab_size, embed_dim)
        self.pos_encoder = PositionalEncoding(embed_dim, dropout)
        self.layers = nn.ModuleList([
            PlantTransformerBlock(embed_dim, nhead, ff_dim, dropout)
            for _ in range(num_layers)
        ])
        self.fc_out = nn.Linear(embed_dim, vocab_size)

    def forward(self, src, plant_signals, return_attn=False):
        x = self.embedding(src)
        x = self.pos_encoder(x)
        attn_matrix = None
        for i, layer in enumerate(self.layers):
            if return_attn and (i == len(self.layers)-1):
                x, attn_matrix = layer(x, plant_signals, return_attn=True)
            else:
                x, _ = layer(x, plant_signals, return_attn=False)
        logits = self.fc_out(x)
        if return_attn:
            return logits, attn_matrix
        return logits

# --- Helper: convert h_vec to plant_signals dict
def hormones_to_dict(h_vec):
    return {name: float(h_vec[i]) for i, name in enumerate(HORMONE_NAMES)}

# ---- LOAD MODEL ----
model = PlantTransformerLM(
    vocab_size=VOCAB_SIZE,
    embed_dim=EMBED_DIM,
    nhead=NHEAD,
    num_layers=NUM_LAYERS,
    ff_dim=FF_DIM,
    dropout=DROPOUT
).to(DEVICE)

model.load_state_dict(torch.load("transformer_lm.pth", map_location=DEVICE))
model.eval()

# ---- INIT hormone net + optimizer ----
h_net = PlantHormoneNetwork().to(DEVICE)
h_optimizer = optim.Adam(h_net.parameters(), lr=PLANT_HORMONE_LR)
h_loss_fn = nn.MSELoss()

def save_hormone_net(h_net, path="hormone_net.pth"):
    torch.save(h_net.state_dict(), path)

def load_hormone_net(h_net, path="hormone_net.pth"):
    h_net.load_state_dict(torch.load(path, map_location=DEVICE))
    h_net.eval()

# ---- Generate ----
def generate_text_and_attention_adaptive_learn(
    model, h_net, h_optimizer, seed, length=50, temperature=1.0, top_k=20, loss_callback=None):
    
    model.eval()
    for p in h_net.parameters():
        p.requires_grad = True

    ids = encode(seed)
    input_ids = ids[:]
    input_tensor = torch.tensor([input_ids], dtype=torch.long).to(DEVICE)
    attn_matrices = []
    h_current = torch.tensor([HORMONE_BASELINES[k] for k in HORMONE_NAMES], device=DEVICE).unsqueeze(0)
    entropy_history = []

    for _ in range(length):
        if input_tensor.size(1) > SEQ_LENGTH:
            input_tensor = input_tensor[:, -SEQ_LENGTH:]
        logits, attn = model(input_tensor, hormones_to_dict(h_current.squeeze(0)), return_attn=True)
        attn_matrices.append(attn.cpu() if attn is not None else None)
        logits_step = logits[0, -1, :] / temperature
        probs = torch.softmax(logits_step, dim=0).detach().cpu().numpy()
        entropy = -np.sum(probs * np.log(probs + 1e-8))
        entropy_torch = torch.tensor([entropy], device=DEVICE)
        entropy_history.append(entropy)
        if len(entropy_history) > 20:
            entropy_history = entropy_history[-20:]
        emb_layer = model.embedding
        if input_tensor.shape[1] == 1:
            last_emb = emb_layer(input_tensor[0, -1:]).view(-1)
            prompt_embs = last_emb
        else:
            last_emb = emb_layer(input_tensor[0, -1:]).view(-1)
            prompt_embs = emb_layer(input_tensor[0, :-1]).mean(dim=0)
        latent_deviation = (last_emb - prompt_embs).unsqueeze(0)
        if latent_deviation.shape[1] < LATENT_DIM:
            latent_deviation = torch.cat([
                latent_deviation,
                torch.zeros(1, LATENT_DIM - latent_deviation.shape[1], device=DEVICE)
            ], dim=1)
        elif latent_deviation.shape[1] > LATENT_DIM:
            latent_deviation = latent_deviation[:, :LATENT_DIM]
        last_token_id = input_tensor[0, -1].item()
        violation_flag = torch.tensor([[float(last_token_id == UNK_ID or entropy > 3.5)]], device=DEVICE)
        memory_feedback = torch.tensor([np.mean(entropy_history)] * MEMORY_DIM, device=DEVICE).unsqueeze(0)
        if input_tensor.shape[1] == 1:
            context_vec = emb_layer(input_tensor[0]).view(1, -1)
        else:
            context_vec = emb_layer(input_tensor[0, :]).mean(dim=0, keepdim=True)
        if context_vec.shape[1] < CONTEXT_DIM:
            context_vec = torch.cat([
                context_vec,
                torch.zeros(1, CONTEXT_DIM - context_vec.shape[1], device=DEVICE)
            ], dim=1)
        elif context_vec.shape[1] > CONTEXT_DIM:
            context_vec = context_vec[:, :CONTEXT_DIM]

        sentiment_torch = torch.tensor([sentiment], device=DEVICE)

        # --- UPDATE hormone state & LEARNING ---
        h_new = h_net(entropy_torch, latent_deviation, violation_flag, h_current, memory_feedback, context_vec, sentiment_torch)

        if loss_callback is not None:
            h_optimizer.zero_grad()
            loss = loss_callback(entropy_torch, violation_flag, h_new)
            loss.backward()
            h_optimizer.step()
        h_new = h_new.detach().clone()
        for i, name in enumerate(HORMONE_NAMES):
            minv, maxv = HORMONE_MINMAX[name]
            h_new[0, i] = torch.clamp(h_new[0, i], min=minv, max=maxv)

        h_current = h_new

        # --- GENERATE next token ---
        if top_k > 0:
            top_k_logits, top_k_indices = torch.topk(logits_step, top_k)
            probs_top = torch.softmax(top_k_logits, dim=0)
            next_token = top_k_indices[torch.multinomial(probs_top, 1)].item()
        else:
            probs_all = torch.softmax(logits_step, dim=0)
            next_token = torch.multinomial(probs_all, 1).item()
        input_tensor = torch.cat([input_tensor, torch.tensor([[next_token]], device=DEVICE)], dim=1)
        input_ids.append(next_token)
        if next_token == EOS_ID:
            break
    return decode(input_ids), attn_matrices, h_current

print("Chat started with adaptive plant hormone signals, emoční reakcí a on-line hormonálním učením.")
print("Type 'exit' to quit, or type 'save_hormone'/'load_hormone' to save/load hormone net.")

try:
    while True:
        user_in = input("\nuser: ")
        if user_in.strip().lower() in ['exit', 'konec', 'quit']:
            print("Exiting chat.")
            break
        if user_in.strip().lower() == "save_hormone":
            save_hormone_net(h_net)
            print("Hormone network saved.")
            continue
        if user_in.strip().lower() == "load_hormone":
            load_hormone_net(h_net)
            print("Hormone network loaded.")
            continue

        prompt = f"user: {user_in} model:"
        # --- Sentiment analýza uživatelského vstupu ---
        sentiment = get_sentiment_score(user_in)
        print(f"(Sentiment skóre vstupu: {sentiment:.3f})")  # Volitelný debug výpis

        # --- Custom reward/loss function for on-line hormone learning (configurable) ---
        def loss_callback(entropy_torch, violation_flag, h_new):
            target_h = torch.tensor([HORMONE_BASELINES[k] for k in HORMONE_NAMES], device=DEVICE).unsqueeze(0)
            reward = -entropy_torch
            alpha = PLANT_HORMONE_LOSS_ALPHA
            beta = PLANT_HORMONE_LOSS_BETA
            gamma = PLANT_HORMONE_LOSS_GAMMA
            return (
                alpha * h_loss_fn(h_new, target_h)
                + beta * reward.abs()
                + gamma * violation_flag.abs().mean()
            )

        response, attn_matrices, h_current = generate_text_and_attention_adaptive_learn(
            model, h_net, h_optimizer, prompt, length=40, temperature=1.0, top_k=40,
            loss_callback=loss_callback,
            sentiment=sentiment  # << DŮLEŽITÉ! předání do funkce
        )
        print("Model:", response.split("Model:",1)[-1].strip())

        # --- Display hormones value ---
        hormone_levels = hormones_to_dict(h_current.squeeze(0))
        print("Aktuální hormonální profil:")
        for name, value in hormone_levels.items():
            print(f"  {name}: {value:.4f}")

        # --- Displaying last attention (average over heads, with tokens if not too long) ---
        if attn_matrices and attn_matrices[-1] is not None:
            attn = attn_matrices[-1][0]
            avg_attn = attn.mean(dim=0).detach().cpu().numpy()
            input_tokens = decode(encode(prompt)).split()
            seq_len = avg_attn.shape[0]
            plt.figure(figsize=(6, 6))
            plt.imshow(avg_attn[:seq_len, :seq_len], aspect='auto', vmin=0, vmax=1)
            plt.title("Attention heatmap (average over heads, last step)")
            if len(input_tokens) <= 40:
                plt.xticks(range(len(input_tokens)), input_tokens, rotation=90)
                plt.yticks(range(len(input_tokens)), input_tokens)
            plt.xlabel("Position in sequence")
            plt.ylabel("Position in sequence")
            plt.colorbar()
            plt.tight_layout()
            #plt.show()
except KeyboardInterrupt:
    print("\nChat interrupted. Exiting.")