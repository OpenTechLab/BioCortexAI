import os
import torch
import torch.nn as nn
import torch.optim as optim
from torch.utils.data import Dataset, DataLoader
import random
import json
from datetime import datetime
import sentencepiece as spm
from config import *

# ========== Biochemical signals ==========
def plant_network_sim(dopamine=None, serotonin=None, cortisol=None, oxytocin=None):
    levels = {"low": 0.3, "normal": 1.0, "high": 1.7, "neutral": 0.0}
    return {
        "dopamine": levels[dopamine or "normal"],
        "serotonin": levels[serotonin or "normal"],
        "cortisol": levels[cortisol or "normal"],
        "oxytocin": levels[oxytocin or "neutral"],
    }

print("Inicializing SentencePiece...")
sp = spm.SentencePieceProcessor()
sp.load("cz_spm.model")
VOCAB_SIZE = sp.get_piece_size()
PAD_ID = sp.piece_to_id("<PAD>")
BOS_ID = sp.piece_to_id("<BOS>")
EOS_ID = sp.piece_to_id("<EOS>")
UNK_ID = sp.unk_id()

def encode(text):
    return sp.encode(text, out_type=int)
def decode(indices):
    return sp.decode(indices)

# ========== Random seed from dataset ===========

def get_random_user_prompt(dataset):
    tries = 10
    N = len(dataset)
    for _ in range(tries):
        idx = random.randint(0, N - 1)
        dataset._open_file()
        dataset._file.seek(dataset.line_offsets[idx])
        row = dataset._file.readline().strip()
        if row.startswith("user:") and "model:" in row:
            end = row.index("model:")
            prompt = row[:end].strip()
            return prompt
    # fallback:
    return "user: Hello, model!"

# ========== RAM friendly dataset ==========
class UltraLazyTextDataset(Dataset):
    def __init__(self, filename, seq_length, tokenizer):
        self.filename = filename
        self.seq_length = seq_length
        self.tokenizer = tokenizer
        self.line_offsets = []
        with open(filename, "r", encoding="utf-8") as f:
            while True:
                pos = f.tell()
                line = f.readline()
                if not line:
                    break
                self.line_offsets.append(pos)
        self.n_lines = len(self.line_offsets)
        self._file = None

    def __len__(self):
        return self.n_lines

    def _open_file(self):
        if self._file is None:
            self._file = open(self.filename, "r", encoding="utf-8")

    def _close_file(self):
        if self._file:
            self._file.close()
            self._file = None

    def __getitem__(self, idx):
        self._open_file()
        self._file.seek(self.line_offsets[idx])
        line = self._file.readline().strip()
        ids = self.tokenizer.encode(line)
        seq = ids[:self.seq_length]
        target = ids[1:self.seq_length+1]
        seq = seq + [PAD_ID] * (self.seq_length - len(seq))
        target = target + [PAD_ID] * (self.seq_length - len(target))
        target = [t if t < VOCAB_SIZE else UNK_ID for t in target]
        seq = [s if s < VOCAB_SIZE else UNK_ID for s in seq]
        return torch.tensor(seq, dtype=torch.long), torch.tensor(target, dtype=torch.long)


train_dataset = UltraLazyTextDataset(
    filename=DATA_DIR,
    seq_length=SEQ_LENGTH,
    tokenizer=sp
)
train_loader = DataLoader(
    train_dataset,
    batch_size=BATCH_SIZE,
    shuffle=True,
    num_workers=0,       # Musí být 0!
    pin_memory=False,
    drop_last=True
)

# ========== Masks ==========
def generate_square_subsequent_mask(sz, device):
    mask = torch.tril(torch.ones(sz, sz, device=device)).bool()
    return mask.unsqueeze(0).unsqueeze(0)
def create_pad_mask(seq, pad_id=PAD_ID):
    return (seq != pad_id).unsqueeze(1).unsqueeze(2)

# ========== Attention ==========
class ModulatedMultiHeadAttention(nn.Module):
    def __init__(self, embed_dim, num_heads, dropout=0.1):
        super().__init__()
        self.embed_dim = embed_dim
        self.num_heads = num_heads
        self.dropout = nn.Dropout(dropout)
        assert embed_dim % num_heads == 0
        self.head_dim = embed_dim // num_heads
        self.W_q = nn.Linear(embed_dim, embed_dim)
        self.W_k = nn.Linear(embed_dim, embed_dim)
        self.W_v = nn.Linear(embed_dim, embed_dim)
        self.out_proj = nn.Linear(embed_dim, embed_dim)
    def forward(self, x, plant_signals, attn_mask=None, causal_mask=None):
        if x.dim() == 2:
            x = x.unsqueeze(0)
        B, T, D = x.shape
        q = self.W_q(x).view(B, T, self.num_heads, self.head_dim).transpose(1,2)
        k = self.W_k(x).view(B, T, self.num_heads, self.head_dim).transpose(1,2)
        v = self.W_v(x).view(B, T, self.num_heads, self.head_dim).transpose(1,2)
        attn_scores = torch.matmul(q, k.transpose(-2, -1)) / (self.head_dim ** 0.5)
        if causal_mask is not None:
            attn_scores = attn_scores.masked_fill(~causal_mask, float('-inf'))
        if attn_mask is not None:
            attn_scores = attn_scores.masked_fill(~attn_mask, float('-inf'))
        all_inf_rows = torch.isinf(attn_scores).all(dim=-1, keepdim=True)
        if all_inf_rows.any():
            attn_scores = attn_scores.masked_fill(all_inf_rows, 0.0)
        dopamine = plant_signals['dopamine']
        serotonin = plant_signals['serotonin']
        cortisol = plant_signals['cortisol']
        oxytocin = plant_signals['oxytocin']
        attn_scores = attn_scores * dopamine
        attn_scores = attn_scores + (serotonin - 1.0)
        attn_scores = attn_scores + torch.randn_like(attn_scores) * ((cortisol - 1.0) * 0.05)
        mean_scores = attn_scores.mean(dim=1, keepdim=True)
        attn_scores = attn_scores * (1 - oxytocin) + mean_scores * oxytocin
        if torch.isnan(attn_scores).any() or torch.isinf(attn_scores).any():
            attn_scores = torch.nan_to_num(attn_scores, nan=0.0, posinf=0.0, neginf=0.0)
        attn_weights = torch.softmax(attn_scores, dim=-1)
        attn_output = torch.matmul(attn_weights, v)
        attn_output = attn_output.transpose(1,2).contiguous().view(B, T, D)
        out = self.out_proj(attn_output)
        return out, attn_weights

class PlantTransformerEncoderLayer(nn.Module):
    def __init__(self, embed_dim, num_heads, ff_dim, dropout=0.1):
        super().__init__()
        self.self_attn = ModulatedMultiHeadAttention(embed_dim, num_heads, dropout)
        self.linear1 = nn.Linear(embed_dim, ff_dim)
        self.dropout = nn.Dropout(dropout)
        self.linear2 = nn.Linear(ff_dim, embed_dim)
        self.norm1 = nn.LayerNorm(embed_dim)
        self.norm2 = nn.LayerNorm(embed_dim)
        self.activation = nn.ReLU()
    def forward(self, src, plant_signals, attn_mask=None, causal_mask=None, return_attn=False):
        src2, attn_weights = self.self_attn(src, plant_signals, attn_mask=attn_mask, causal_mask=causal_mask)
        src = src + self.dropout(src2)
        src = self.norm1(src)
        src2 = self.linear2(self.dropout(self.activation(self.linear1(src))))
        src = src + self.dropout(src2)
        src = self.norm2(src)
        if return_attn:
            return src, attn_weights
        return src, None

class PositionalEncoding(nn.Module):
    def __init__(self, d_model, dropout=0.1, max_len=5000):
        super().__init__()
        self.dropout = nn.Dropout(dropout)
        pe = torch.zeros(max_len, d_model)
        position = torch.arange(0, max_len, dtype=torch.float).unsqueeze(1)
        div_term = torch.exp(torch.arange(0, d_model, 2).float() * (-torch.log(torch.tensor(10000.0)) / d_model))
        pe[:, 0::2] = torch.sin(position * div_term)
        pe[:, 1::2] = torch.cos(position * div_term)
        pe = pe.unsqueeze(0)
        self.register_buffer('pe', pe)
    def forward(self, x):
        x = x + self.pe[:, :x.size(1), :]
        return self.dropout(x)

class PlantTransformerLM(nn.Module):
    def __init__(self, vocab_size, embed_dim, nhead, num_layers, ff_dim, dropout):
        super().__init__()
        self.embedding = nn.Embedding(vocab_size, embed_dim, padding_idx=PAD_ID)
        self.pos_encoder = PositionalEncoding(embed_dim, dropout)
        self.layers = nn.ModuleList([
            PlantTransformerEncoderLayer(embed_dim, nhead, ff_dim, dropout)
            for _ in range(num_layers)
        ])
        self.fc_out = nn.Linear(embed_dim, vocab_size)
    def forward(self, src, plant_signals, return_attn_from_layer=None):
        x = self.embedding(src)
        x = self.pos_encoder(x)
        attn_weights = None
        pad_mask = create_pad_mask(src)
        causal_mask = generate_square_subsequent_mask(src.size(1), src.device)
        for idx, layer in enumerate(self.layers):
            if return_attn_from_layer is not None and idx == return_attn_from_layer:
                x, attn_weights = layer(x, plant_signals, attn_mask=pad_mask, causal_mask=causal_mask, return_attn=True)
            else:
                x, _ = layer(x, plant_signals, attn_mask=pad_mask, causal_mask=causal_mask)
        logits = self.fc_out(x)
        if return_attn_from_layer is not None:
            return logits, attn_weights
        return logits

def save_model(model, path="transformer_lm.pth"):
    torch.save(model.state_dict(), path)
def load_model(model, path="transformer_lm.pth"):
    model.load_state_dict(torch.load(path, map_location=DEVICE))
    model.eval()

model = PlantTransformerLM(
    vocab_size=VOCAB_SIZE,
    embed_dim=EMBED_DIM,
    nhead=NHEAD,
    num_layers=NUM_LAYERS,
    ff_dim=FF_DIM,
    dropout=DROPOUT
).to(DEVICE)

print(f"Total number of parameters: {sum(p.numel() for p in model.parameters())}")

optimizer = optim.Adam(model.parameters(), lr=LR)

if os.path.exists("transformer_lm.pth"):
    load_model(model, "transformer_lm.pth")
    optimizer.load_state_dict(torch.load("optimizer.pth"))
    print("Model and optimizer loaded — you can continue training!")
else:
    print("Starting training from scratch…")

if os.path.exists("training_state.json"):
    with open("training_state.json") as f:
        d = json.load(f)
        START_EPOCH = d.get("last_epoch", 0)
else:
    START_EPOCH = 0

print(f"Starting training from epoch {START_EPOCH+1}")

criterion = nn.CrossEntropyLoss(ignore_index=PAD_ID)
TOTAL_EPOCHS = START_EPOCH + NUM_EPOCHS

print("Start… " + datetime.now().strftime("%H:%M"))

for epoch in range(START_EPOCH, TOTAL_EPOCHS):
    train_dataset._open_file()
    epoch_start = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
    model.train()
    total_loss = 0
    n_batches = len(train_loader)
    for i, (batch_x, batch_y) in enumerate(train_loader):
        batch_x = batch_x.to(DEVICE)
        batch_y = batch_y.to(DEVICE)
        valid_rows = (batch_x != PAD_ID).any(dim=1)
        if valid_rows.sum() == 0:
            continue
        batch_x = batch_x[valid_rows]
        batch_y = batch_y[valid_rows]
        optimizer.zero_grad()
        plant_signals = plant_network_sim()
        logits = model(batch_x, plant_signals)
        if torch.isnan(logits).any() or torch.isinf(logits).any():
            continue
        loss = criterion(logits.view(-1, VOCAB_SIZE), batch_y.view(-1))
        if torch.isnan(loss) or torch.isinf(loss):
            continue
        loss.backward()
        optimizer.step()
        total_loss += loss.item()
        if (i+1) % max(1, n_batches // 50) == 0 or i+1 == n_batches:
            progress = int(50 * (i+1) / n_batches)
            bar = "●" * progress + "-" * (50 - progress)
            percent = 100 * (i+1) // n_batches
            print(f"\rEpoch {epoch+1}/{TOTAL_EPOCHS} | [{bar}] {percent}%", end="")
    train_dataset._close_file()
    print()
    avg_loss = total_loss / n_batches
    print(f"{epoch_start} | Epoch {epoch+1}/{TOTAL_EPOCHS} | Loss: {avg_loss:.4f}")
    with open("training_state.json", "w") as f:
        json.dump({"last_epoch": epoch + 1}, f)

def generate_text(model, seed, plant_signals=None, length=50, temperature=1.0, top_k=20):
    model.eval()
    with torch.no_grad():
        ids = encode(seed)
        input_ids = ids[:]
        input_tensor = torch.tensor([input_ids], dtype=torch.long).to(DEVICE)
        for _ in range(length):
            if input_tensor.size(1) > SEQ_LENGTH:
                input_tensor = input_tensor[:, -SEQ_LENGTH:]
            logits = model(input_tensor, plant_signals or plant_network_sim())
            logits = logits[0, -1, :] / temperature
            probs = torch.softmax(logits, dim=0)
            if torch.isnan(probs).any():
                break
            if top_k > 0:
                top_k_logits, top_k_indices = torch.topk(logits, top_k)
                probs = torch.softmax(top_k_logits, dim=0)
                next_token = top_k_indices[torch.multinomial(probs, 1)].item()
            else:
                next_token = torch.multinomial(probs, 1).item()
            input_tensor = torch.cat([input_tensor, torch.tensor([[next_token]], device=DEVICE)], dim=1)
            input_ids.append(next_token)
            if next_token == EOS_ID:
                break
        return decode(input_ids)

print("Test:")
try:
    random_seed = get_random_user_prompt(train_dataset)
    prompt = random_seed + " model: "
    print(generate_text(model, prompt, plant_signals=plant_network_sim(), length=128))
except Exception as e:
    print("Generating error:", e)

save_model(model, "transformer_lm.pth")
torch.save(optimizer.state_dict(), "optimizer.pth")
