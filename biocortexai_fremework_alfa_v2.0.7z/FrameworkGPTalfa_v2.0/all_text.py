import os
import chardet

DATA_DIR = "./dataset"
OUTPUT_FILE = "all_text.txt"
files = [f for f in os.listdir(DATA_DIR) if f.endswith(".txt")]

with open(OUTPUT_FILE, "w", encoding="utf-8") as outfile:
    for fname in files:
        path = os.path.join(DATA_DIR, fname)
        # Load data 
        with open(path, "rb") as f:
            raw = f.read()
            result = chardet.detect(raw)
            enc = result["encoding"]
            if enc is None:
                print(f"Attention: {fname} encoding failed, skipped.")
                continue
            try:
                text = raw.decode(enc, errors="ignore")
                outfile.write(text + "\n")
                print(f"File {fname} ({enc}) added to all_text.txt ({len(text)} characters).")
            except Exception as e:
                print(f"Failed reading {fname}: {e}")

print(f"\nFinished!")
