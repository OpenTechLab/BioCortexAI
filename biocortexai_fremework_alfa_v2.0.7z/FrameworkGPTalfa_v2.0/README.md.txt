README.md
BioCortexAI – Emotionally Modulated Transformer Framework
Version: alpha_v2.0

1. Introduction & Motivation

BioCortexAI is an experimental open-source framework for transformer-based language models, uniquely integrating biologically-inspired “hormonal” modulation directly into attention and memory mechanisms.
Instead of simulating emotions only in outputs, BioCortexAI injects hormone-like signals (dopamine, serotonin, cortisol, oxytocin) inside the transformer, dynamically shaping the model’s behavior in real time.
Inspired by adaptive regulation in plants (not animals), BioCortexAI enables new directions in affective computing, adaptive systems, and artificial introspection research.

2. What’s New in alpha_v2.0

PlantHormoneNetwork: New neural network module that learns to update the internal hormone profile online, based on user sentiment, model state, and generation feedback.
Online Hormone Learning: The chatbot can now adjust its internal “emotional state” dynamically, learning from each chat turn.
Sentiment Integration: User input is translated and analyzed for sentiment (using transformers), directly influencing hormone levels.
Configurable & Scalable: More detailed parameters in config.py for model/hormone network architecture and training dynamics.
Efficient Dataset Handling: Ultra RAM-efficient lazy data loading for large corpora.
Expanded Commands: In-chat saving/loading of hormone state (save_hormone, load_hormone), plus visualization of attention heads.
Improved Tokenizer & Multilingual Support: SentencePiece tokenizer setup; can be reconfigured for different languages.
Enhanced Training Pipeline: Robust checkpointing, sample generation after epochs, error handling.

3. Project Structure

BioCortexAI/
│
├─ dataset/                 # Directory for your .txt data files
├─ README.md
├─ config.py                # All hyperparameters & hormone settings
├─ all_text.py              # Merge/convert all text files to UTF-8 dataset
├─ mix_lines.py             # Shuffle dataset lines for robustness
├─ train_model.py           # Training pipeline (with hormone modulation)
├─ chat_me_learn.py         # CLI chatbot: interactive mode, online hormone learning, visualization
├─ plant_hormone_network.py # Hormone net: learns to adapt model’s “emotional” state
├─ cz_spm.model             # SentencePiece tokenizer model (generated)
├─ all_text.txt             # Combined, preprocessed dataset (generated)
├─ transformer_lm.pth       # Trained model weights (generated)
├─ hormone_net.pth          # Hormone network weights (after chat learning, generated)

4. Installation & Dependencies

Python: 3.11 or lower (recommended for compatibility)

Required Libraries:

torch (PyTorch, matching your CUDA environment)
sentencepiece
chardet
matplotlib
numpy
transformers
deep_translator #for other languages than english


Install Example:

pip install torch torchvision torchaudio --index-url https://download.pytorch.org/whl/cu126  # Adjust for your CUDA/GPU
pip install sentencepiece chardet matplotlib numpy transformers deep-translator

5. Data Preparation

Add Data:
Place all your .txt files into the ./dataset/ directory.

Merge and Convert to UTF-8:

python all_text.py
Produces all_text.txt (single UTF-8 merged dataset).

Shuffle Lines (Optional, Recommended):

python mix_lines.py
Improves training robustness.

Train the Tokenizer:
(Adjust parameters for your language/data size as needed)

bash:

python -c "
import sentencepiece as spm
spm.SentencePieceTrainer.train(
  input='all_text.txt',
  model_prefix='cz_spm',
  vocab_size=64000,
  model_type='bpe',
  character_coverage=0.9995,
  user_defined_symbols=['<PAD>', '<BOS>', '<EOS>']
)"

This creates cz_spm.model (tokenizer).

6. Configuration

Edit config.py to set all key model and hormone net parameters.
Main options:

DATA_DIR = "./all_text.txt"  # Your main dataset file
SEQ_LENGTH = 128
BATCH_SIZE = 16
EMBED_DIM = 256
NHEAD = 8
NUM_LAYERS = 12
FF_DIM = 1024
DROPOUT = 0.15
LR = 1e-5
NUM_EPOCHS = 1
DEVICE = "cuda"  # or "cpu"
MIN_WORD_FREQ = 3

# Hormone settings
HORMONE_NAMES = ["dopamine", "serotonin", "cortisol", "oxytocin"]
HORMONE_BASELINES = { 1.0, 1.0, 1.0, 0.0 }
HORMONE_MINMAX = { 0.0, 2.0 }

# PlantHormoneNetwork hyperparameters
PLANT_HORMONE_LR = 1e-3
PLANT_HORMONE_LOSS_ALPHA = 0.1
PLANT_HORMONE_LOSS_BETA = 1.0
PLANT_HORMONE_LOSS_GAMMA = 0.5

Fine-tune these according to your dataset and experiment needs!

7. Model Training

Launch training:

python train_model.py

Uses RAM-efficient dataset loader (UltraLazyTextDataset)
Trains transformer with hormone-modulated attention
Periodically saves checkpoints (transformer_lm.pth, optimizer.pth, training_state.json)
Prints sample generations for validation
You can resume training from the latest checkpoint automatically.

8. Interactive Chat & Inference

Start the adaptive, emotionally modulated chat:

python chat_me_learn.py

Features:

Real-time user input, context-aware replies
Automatic user sentiment analysis (translation to English, transformer-based sentiment)
Hormone state updated after every turn (using PlantHormoneNetwork)
Online hormone net learning (reward via entropy, violation flags, sentiment)
Displays current hormone levels after every response
Optional: Attention head heatmap visualization (with matplotlib)

Commands:

save_hormone – Save current hormone network weights (hormone_net.pth)
load_hormone – Load hormone network state
exit/quit – End chat

9. Hormone Modulation Effects

Dopamine: Increases attention “sharpness”, stronger focus, more decisive outputs
Serotonin: Shifts average attention, subtly biases what’s prioritized
Cortisol: Adds randomness/chaos (higher entropy) to attention, making outputs more diverse or erratic
Oxytocin: Unifies attention heads, creating more “cohesive” and contextually aligned responses

Hormone levels are dynamically controlled and visualized, so you can see and influence the model’s emotional “mood” in real time!

10. Scientific Background & References

BioCortexAI is inspired by biological research into adaptive regulation, plant hormone signaling, and non-anthropocentric AI.
Key Publications:

A Functional and Non-Anthropocentric Definition of Consciousness [https://zenodo.org/records/16041392]
Hybrid Architectures of Artificial Intelligence for Adaptive Systems [https://zenodo.org/records/16041708]

11. License

Creative Commons Attribution-NonCommercial 4.0 (CC BY-NC 4.0)
Free to share and remix for non-commercial purposes, with attribution
Full license text: https://creativecommons.org/licenses/by-nc/4.0/legalcode

12. Credits
Developed by Michal Seidl & the OpenTechLab Jablonec nad Nisou team
Web: www.biocortexai.eu
www.opentechlab.cz

13. Notes & Best Practices

Experiment Freely: Try new hormone types, tune learning weights, or test with different languages and datasets.
Model Quality: Heavily depends on your dataset size/quality and hyperparameter choices.
This is alpha software: Expect bugs and changes; feedback and collaboration are welcome!
For questions, suggestions, or collaboration, contact the authors via e-mail: vyvoj@opentechlab.cz!
