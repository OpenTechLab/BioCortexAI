import random

with open("all_text.txt", "r", encoding="utf-8") as f:
    lines = f.readlines()

random.shuffle(lines)

with open("all_text.txt", "w", encoding="utf-8") as f:
    f.writelines(lines)
