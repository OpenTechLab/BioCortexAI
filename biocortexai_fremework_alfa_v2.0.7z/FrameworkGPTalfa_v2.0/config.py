# config.py

import torch

DATA_DIR = "./all_text.txt"
SEQ_LENGTH = 128        # Input sequence length
BATCH_SIZE = 16
EMBED_DIM = 256        # embedding dimenzion
NHEAD = 16              # Number of heads in multihead attention
NUM_LAYERS = 12         # Number of transformer blocks
FF_DIM = 1024           # Size of the inner feedforward layer
DROPOUT = 0.1
LR = 1e-5              # learning rate
NUM_EPOCHS = 1         # Number of epochs
DEVICE = "cuda" if torch.cuda.is_available() else "cpu"
MIN_WORD_FREQ = 3      # Minimum word frequency for inclusion in the vocabulary


# --- Hormonal Norms ---
HORMONE_NAMES = ["dopamine", "serotonin", "cortisol", "oxytocin"]

HORMONE_BASELINES = {
    "dopamine": 1.0,
    "serotonin": 1.0,
    "cortisol": 1.0,
    "oxytocin": 0.0
}

HORMONE_MINMAX = {
    "dopamine": (0.1, 2.0),
    "serotonin": (0.1, 2.0),
    "cortisol": (0.1, 2.0),
    "oxytocin": (0.0, 2.0)
}

HORMONE_DIM = len(HORMONE_NAMES)
CONTEXT_DIM = 16         # případně uprav dle architektury
LATENT_DIM = 16
MEMORY_DIM = 4

# --- Hyperparameters for the PlantHormoneNetwork's learning ---
PLANT_HORMONE_LR = 1e-3        # Learning rate pro optimizer
PLANT_HORMONE_LOSS_ALPHA = 0.1 # Homeostasis weight (MSE on the hormonal profile 0-1) – this indicates how strongly the network attempts to restore hormonal levels. A lower alpha value means weaker homeostasis.
PLANT_HORMONE_LOSS_BETA = 1.0  # Entropy penalty weight (reward) - A lower beta value means entropy has less influence, and the network is more guided by homeostasis.
PLANT_HORMONE_LOSS_GAMMA = 0.5 # Violation penalty weight - A higher gamma value means the model more strongly penalizes outputs where a violation has occurred (e.g., an UNK token or another error).
