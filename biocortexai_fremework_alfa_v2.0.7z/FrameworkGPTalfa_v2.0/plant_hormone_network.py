# plant_hormone_network.py
# This is an alpha version of a prototype minimalist neural network, 
# based on distributed processing and the spatiotemporal organization of information in plants. 
# Improvements and extensions are currently under development.


import torch
import torch.nn as nn
import torch.nn.functional as F
from config import HORMONE_DIM, CONTEXT_DIM, LATENT_DIM, MEMORY_DIM, HORMONE_BASELINES, HORMONE_MINMAX

class PlantHormoneNetwork(nn.Module):
    def __init__(self):
        super().__init__()
        input_dim = (
            1 + LATENT_DIM + 1 + HORMONE_DIM + MEMORY_DIM + CONTEXT_DIM + 1  # sentiment navíc
        )
        hidden_dim = 32

        self.layernorm_in = nn.LayerNorm(input_dim)
        self.fc1 = nn.Linear(input_dim, hidden_dim)
        self.fc2 = nn.Linear(hidden_dim, HORMONE_DIM)

    def forward(self, entropy, latent_deviation, violation_flags, h, memory_feedback, context, sentiment):
        x = torch.cat([
            entropy.view(-1, 1),
            latent_deviation,
            violation_flags.view(-1, 1),
            h,
            memory_feedback,
            context,
            sentiment.view(-1, 1)   # << NOVÝ VSTUP
        ], dim=-1)
        x = self.layernorm_in(x)
        x = F.relu(self.fc1(x))
        raw_out = self.fc2(x)  # [B, HORMONE_DIM]

        # --- Hormonal Norms and Treatment Ranges ---
        hormone_out = []
        for i, hormone in enumerate(HORMONE_BASELINES):
            baseline = HORMONE_BASELINES[hormone]
            minv, maxv = HORMONE_MINMAX[hormone]
            if hormone == "oxytocin":
                val = baseline + F.softplus(raw_out[:, i])
                val = torch.clamp(val, minv, maxv)
            else:
                val = baseline + 0.9 * torch.tanh(raw_out[:, i])
                val = torch.clamp(val, minv, maxv)
            hormone_out.append(val.unsqueeze(1))
        h_new = torch.cat(hormone_out, dim=1)
        return h_new


# --- TEST, INTEGRATION ---
if __name__ == "__main__":
    net = PlantHormoneNetwork()
    B = 2
    entropy = torch.rand(B)
    latent_deviation = torch.randn(B, LATENT_DIM)
    violation_flags = torch.rand(B)
    h = torch.rand(B, HORMONE_DIM)
    memory_feedback = torch.rand(B, MEMORY_DIM)
    context = torch.randn(B, CONTEXT_DIM)
    h_new = net(entropy, latent_deviation, violation_flags, h, memory_feedback, context)
    print(h_new)
