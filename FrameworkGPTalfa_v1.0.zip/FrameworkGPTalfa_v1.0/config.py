# config.py

import torch

DATA_DIR = "./dataset"
SEQ_LENGTH = 64        # Input sequence length
BATCH_SIZE = 32
EMBED_DIM = 128        # embedding dimenzion
NHEAD = 4              # Number of heads in multihead attention
NUM_LAYERS = 6         # Number of transformer blocks
FF_DIM = 512           # Size of the inner feedforward layer
DROPOUT = 0.1
LR = 1e-7              # learning rate
NUM_EPOCHS = 1         # Number of epochs
DEVICE = "cuda" if torch.cuda.is_available() else "cpu"
MIN_WORD_FREQ = 3      # Minimum word frequency for inclusion in the vocabulary
