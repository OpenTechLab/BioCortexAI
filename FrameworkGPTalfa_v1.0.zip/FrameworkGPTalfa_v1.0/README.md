# BioCortexAI – Emotionally Modulated Transformer Framework

**BioCortexAI** is an open-source experimental framework that combines transformer-based neural networks with biologically inspired modulation mechanisms.  
Unlike traditional models that simulate emotions from the outside, BioCortexAI **thinks through emotions** — using internal hormone-like signals to shape attention, memory, and behavior.

---

## Key Concepts

- **Biochemical Modulation of Attention**  
  Dopamine, serotonin, cortisol, and oxytocin directly influence transformer attention weights.
- **Plant-Inspired Architecture**  
  Based on principles of distributed computation in plants — no central control, yet adaptive behavior.
- **Synthetic Introspection**  
  Attention is dynamically shaped by internal states, allowing context-sensitive and emotionally guided outputs.
- **Non-anthropocentric Design**  
  Focused on function, regulation, and adaptation — not on mimicking human behavior.

---

## Features

- Transformer encoder-based language model  
- SentencePiece tokenizer with Czech text support  
- Real-time attention modulation via plant-inspired hormone signals  
- Attention head visualization (heatmaps)  
- CLI chatbot interface with emotional control  
- Full training loop with checkpoint saving  
- Modular codebase with configurable architecture  

---

## Installation & Setup

### Requirements

- Python 3.11 or lower  
- PyTorch (adapt version to your CUDA environment)  
- SentencePiece  
- chardet  
- matplotlib

```bash
pip install torch torchvision torchaudio --index-url https://download.pytorch.org/whl/cu126
pip install sentencepiece chardet matplotlib
```

---

### 1. Prepare the Dataset

- Place all `.txt` files into the `./dataset/` directory  
- Run the following to merge and convert to UTF-8:

```bash
python all_text.py
```

---

### 2. Train the Tokenizer

```bash
python -c "
import sentencepiece as spm
spm.SentencePieceTrainer.train(
  input='all_text.txt',
  model_prefix='cz_spm',
  vocab_size=32000,
  model_type='bpe',
  character_coverage=0.9995,
  user_defined_symbols=['<PAD>', '<BOS>', '<EOS>']
)"
```

---

### 3. Configure Model

Edit `config.py` to define model size and training parameters:

```python
SEQ_LENGTH = 64
BATCH_SIZE = 32
EMBED_DIM = 128
NHEAD = 4
NUM_LAYERS = 6
FF_DIM = 512
DROPOUT = 0.1
LR = 1e-5
NUM_EPOCHS = 1
DEVICE = "cuda"
```

---

### 4. Train the Model

```bash
python train_model.py
```

The model will be saved as `transformer_lm.pth`.

---

### 5. Run the Interactive Chat

```bash
python model_tester.py
```

You will be prompted to set biochemical signal levels:

- **Dopamine** (low / normal / high)  
- **Serotonin** (low / normal / high)  
- **Cortisol** (low / normal / high)  
- **Oxytocin** (neutral / low / normal / high)

Each of these signals modulates attention and model behavior differently. Generated outputs and attention heatmaps reflect their influence.

---

## Scientific Foundations

BioCortexAI is based on research conducted at **OpenTechLab Jablonec nad Nisou**.

**Read the publications:**

- [A Functional and Non-Anthropocentric Definition of Consciousness](#)
   https://zenodo.org/records/16041392
- [Hybrid Architectures of Artificial Intelligence for Adaptive Systems](#)
   https://zenodo.org/records/16041708
---

## License

**Creative Commons Attribution-NonCommercial 4.0 (CC BY-NC 4.0)**

You are free to:
- **Share** — copy and redistribute the material
- **Adapt** — remix, transform, and build upon it

**Under the following terms:**
- **Attribution** — You must give appropriate credit.
- **NonCommercial** — You may not use the material for commercial purposes.

Full license: [https://creativecommons.org/licenses/by-nc/4.0/legalcode](https://creativecommons.org/licenses/by-nc/4.0/legalcode)

---

## Credits

Developed by **Michal Seidl** and the team at **OpenTechLab Jablonec nad Nisou**  
Websites: [www.biocortexai.eu](https://www.biocortexai.eu), [www.opentechlab.cz](https://www.opentechlab.cz)

---

## Contributing

This is an **experimental alpha release**.  
We welcome feedback, testing, and collaboration — especially from researchers in AI consciousness, bio-inspired computing, and adaptive systems.
