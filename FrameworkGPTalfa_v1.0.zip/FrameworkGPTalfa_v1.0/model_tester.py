import torch
import torch.nn as nn
import sentencepiece as spm
import matplotlib.pyplot as plt
from config import *

# --- Tokenizer ---
sp = spm.SentencePieceProcessor()
sp.load("cz_spm.model")

VOCAB_SIZE = sp.get_piece_size()
PAD_ID = sp.piece_to_id("<PAD>")
BOS_ID = sp.piece_to_id("<BOS>")
EOS_ID = sp.piece_to_id("<EOS>")
UNK_ID = sp.unk_id()

def encode(text):
    return sp.encode(text, out_type=int)

def decode(indices):
    return sp.decode(indices)

# --- Positional Encoding ---
class PositionalEncoding(nn.Module):
    def __init__(self, d_model, dropout=0.1, max_len=5000):
        super().__init__()
        self.dropout = nn.Dropout(dropout)
        pe = torch.zeros(max_len, d_model)
        position = torch.arange(0, max_len, dtype=torch.float).unsqueeze(1)
        div_term = torch.exp(torch.arange(0, d_model, 2).float() * (-torch.log(torch.tensor(10000.0)) / d_model))
        pe[:, 0::2] = torch.sin(position * div_term)
        pe[:, 1::2] = torch.cos(position * div_term)
        pe = pe.unsqueeze(0)
        self.register_buffer('pe', pe)

    def forward(self, x):
        x = x + self.pe[:, :x.size(1), :]
        return self.dropout(x)

# --- Biochemical MultiHead Attention ---
class ModulatedMultiHeadAttention(nn.Module):
    def __init__(self, embed_dim, num_heads, dropout=0.1):
        super().__init__()
        self.embed_dim = embed_dim
        self.num_heads = num_heads
        self.dropout = nn.Dropout(dropout)
        assert embed_dim % num_heads == 0
        self.head_dim = embed_dim // num_heads
        self.W_q = nn.Linear(embed_dim, embed_dim)
        self.W_k = nn.Linear(embed_dim, embed_dim)
        self.W_v = nn.Linear(embed_dim, embed_dim)
        self.out_proj = nn.Linear(embed_dim, embed_dim)

    def forward(self, x, plant_signals, return_attn=False):
        B, T, D = x.shape
        q = self.W_q(x).view(B, T, self.num_heads, self.head_dim).transpose(1,2)
        k = self.W_k(x).view(B, T, self.num_heads, self.head_dim).transpose(1,2)
        v = self.W_v(x).view(B, T, self.num_heads, self.head_dim).transpose(1,2)
        attn_scores = torch.matmul(q, k.transpose(-2, -1)) / (self.head_dim ** 0.5)

        # --- MODULATION ---
        dopamine = plant_signals['dopamine']
        serotonin = plant_signals['serotonin']
        cortisol = plant_signals['cortisol']
        oxytocin = plant_signals['oxytocin']

        attn_scores = attn_scores * dopamine
        attn_scores = attn_scores + (serotonin - 1.0)
        attn_scores = attn_scores + torch.randn_like(attn_scores) * (cortisol - 1.0)
        mean_scores = attn_scores.mean(dim=1, keepdim=True)
        attn_scores = attn_scores * (1 - oxytocin) + mean_scores * oxytocin

        attn_weights = torch.softmax(attn_scores, dim=-1)
        attn_output = torch.matmul(attn_weights, v)
        attn_output = attn_output.transpose(1,2).contiguous().view(B, T, D)
        out = self.out_proj(attn_output)
        if return_attn:
            return out, attn_weights
        else:
            return out, None

# --- Plant Transformer Encoder Layer ---
class PlantTransformerBlock(nn.Module):
    def __init__(self, embed_dim, num_heads, ff_dim, dropout):
        super().__init__()
        self.self_attn = ModulatedMultiHeadAttention(embed_dim, num_heads, dropout)
        self.linear1 = nn.Linear(embed_dim, ff_dim)
        self.dropout = nn.Dropout(dropout)
        self.linear2 = nn.Linear(ff_dim, embed_dim)
        self.norm1 = nn.LayerNorm(embed_dim)
        self.norm2 = nn.LayerNorm(embed_dim)
        self.activation = nn.ReLU()

    def forward(self, x, plant_signals, return_attn=False):
        x2, attn = self.self_attn(x, plant_signals, return_attn=return_attn)
        x = x + self.dropout(x2)
        x = self.norm1(x)
        x2 = self.linear2(self.dropout(self.activation(self.linear1(x))))
        x = x + self.dropout(x2)
        x = self.norm2(x)
        if return_attn:
            return x, attn
        else:
            return x, None

# --- PlantTransformerLM ---
class PlantTransformerLM(nn.Module):
    def __init__(self, vocab_size, embed_dim, nhead, num_layers, ff_dim, dropout):
        super().__init__()
        self.embedding = nn.Embedding(vocab_size, embed_dim)
        self.pos_encoder = PositionalEncoding(embed_dim, dropout)
        self.layers = nn.ModuleList([
            PlantTransformerBlock(embed_dim, nhead, ff_dim, dropout)
            for _ in range(num_layers)
        ])
        self.fc_out = nn.Linear(embed_dim, vocab_size)

    def forward(self, src, plant_signals, return_attn=False):
        x = self.embedding(src)
        x = self.pos_encoder(x)
        attn_matrix = None
        for i, layer in enumerate(self.layers):
            if return_attn and (i == len(self.layers)-1):
                x, attn_matrix = layer(x, plant_signals, return_attn=True)
            else:
                x, _ = layer(x, plant_signals, return_attn=False)
        logits = self.fc_out(x)
        if return_attn:
            return logits, attn_matrix
        return logits

# ---- LOAD MODEL ----
model = PlantTransformerLM(
    vocab_size=VOCAB_SIZE,
    embed_dim=EMBED_DIM,
    nhead=NHEAD,
    num_layers=NUM_LAYERS,
    ff_dim=FF_DIM,
    dropout=DROPOUT
).to(DEVICE)

model.load_state_dict(torch.load("transformer_lm.pth", map_location=DEVICE))
model.eval()

# ---- Selection of biochemical state ----
def get_plant_signals():
    levels = {"low": 0.1, "normal": 1.0, "high": 1.9, "neutral": 0.0}
    print("\nEnter biochemical levels for generation (low/normal/high/neutral-oxy):")
    dopamine = input("Dopamin (default normal): ").strip() or "normal"
    serotonin = input("Serotonin (default normal): ").strip() or "normal"
    cortisol = input("Kortizol (default normal): ").strip() or "normal"
    oxytocin = input("Oxytocin (default neutral): ").strip() or "neutral"
    return {
        "dopamine": levels.get(dopamine, 1.0),
        "serotonin": levels.get(serotonin, 1.0),
        "cortisol": levels.get(cortisol, 1.0),
        "oxytocin": levels.get(oxytocin, 0.0),
    }

# ---- Text generation ----
def generate_text_and_attention(model, seed, plant_signals, length=50, temperature=1.0, top_k=40):
    model.eval()
    with torch.no_grad():
        ids = encode(seed)
        input_ids = ids[:]
        input_tensor = torch.tensor([input_ids], dtype=torch.long).to(DEVICE)
        attn_matrices = []
        for _ in range(length):
            if input_tensor.size(1) > SEQ_LENGTH:
                input_tensor = input_tensor[:, -SEQ_LENGTH:]
            logits, attn = model(input_tensor, plant_signals, return_attn=True)
            attn_matrices.append(attn.cpu() if attn is not None else None)
            logits = logits[0, -1, :] / temperature
            if top_k > 0:
                top_k_logits, top_k_indices = torch.topk(logits, top_k)
                probs = torch.softmax(top_k_logits, dim=0)
                next_token = top_k_indices[torch.multinomial(probs, 1)].item()
            else:
                probs = torch.softmax(logits, dim=0)
                next_token = torch.multinomial(probs, 1).item()
            input_tensor = torch.cat([input_tensor, torch.tensor([[next_token]], device=DEVICE)], dim=1)
            input_ids.append(next_token)
            if next_token == EOS_ID:
                break
        return decode(input_ids), attn_matrices

# ---- 5. Chat interface ----
print("Chat started with biochemical levels (dopamin, serotonin, kortizol, oxytocin).")
print("Type 'exit' to quit.")

try:
    while True:
        user_in = input("\nUser: ")
        if user_in.strip().lower() in ['exit', 'konec', 'quit']:
            print("Exiting chat.")
            break
        plant_signals = get_plant_signals()
        prompt = f"user: {user_in}\nModel:"
        response, attn_matrices = generate_text_and_attention(
            model, prompt, plant_signals, length=50, temperature=1.0, top_k=40
        )
        print("Model:", response.split("Model:",1)[-1].strip())

        # --- Displaying last attention (average over heads, with tokens if not too long) ---
        if attn_matrices and attn_matrices[-1] is not None:
            attn = attn_matrices[-1][0]  # batch 0
            avg_attn = attn.mean(dim=0).cpu().numpy()
            input_tokens = decode(encode(prompt)).split()
            seq_len = avg_attn.shape[0]
            plt.figure(figsize=(6, 6))
            plt.imshow(avg_attn[:seq_len, :seq_len], aspect='auto', vmin=0, vmax=1)
            plt.title("Attention heatmap (average over heads, last step)")
            if len(input_tokens) <= 40:
                plt.xticks(range(len(input_tokens)), input_tokens, rotation=90)
                plt.yticks(range(len(input_tokens)), input_tokens)
            plt.xlabel("Position in sequence")
            plt.ylabel("Position in sequence")
            plt.colorbar()
            plt.tight_layout()
            plt.show()
except KeyboardInterrupt:
    print("\nChat interrupted. Exiting.")
