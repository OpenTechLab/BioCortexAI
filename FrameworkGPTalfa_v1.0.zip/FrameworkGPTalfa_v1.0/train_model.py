import os
import torch
import torch.nn as nn
import torch.optim as optim
from torch.utils.data import Dataset, DataLoader
import random
import json
from datetime import datetime
import matplotlib.pyplot as plt  
from config import *
import sentencepiece as spm

def ensure_batch_tensor(tensor):
    if tensor.dim() == 1:
        return tensor.unsqueeze(0)
    return tensor

# ======== Biochemical Signals: ========
def plant_network_sim(dopamine=None, serotonin=None, cortisol=None, oxytocin=None):
    levels = {"low": 0.3, "normal": 1.0, "high": 1.7, "neutral": 0.0}
    return {
        "dopamine": levels[dopamine or "normal"],
        "serotonin": levels[serotonin or "normal"],
        "cortisol": levels[cortisol or "normal"],
        "oxytocin": levels[oxytocin or "neutral"],
    }

# ======== Data and tokenizer (SentencePiece) ========
def load_texts(data_dir):
    all_text = []
    for fname in os.listdir(data_dir):
        if fname.endswith(".txt"):
            with open(os.path.join(data_dir, fname), "r", encoding="utf-8") as f:
                all_text.append(f.read())
    return "\n".join(all_text)

print("Inicializing SentencePiece...")
sp = spm.SentencePieceProcessor()
sp.load("cz_spm.model")
VOCAB_SIZE = sp.get_piece_size()
PAD_ID = sp.piece_to_id("<PAD>")
BOS_ID = sp.piece_to_id("<BOS>")
EOS_ID = sp.piece_to_id("<EOS>")
UNK_ID = sp.unk_id()

def encode(text):
    return sp.encode(text, out_type=int)
def decode(indices):
    return sp.decode(indices)

print("Loading data…")
raw_text = load_texts(DATA_DIR)
print(f"Number of characters in the corpus: {len(raw_text)}")
print(f"Vocabulary size of SentencePiece: {VOCAB_SIZE}")

def make_sequences(raw_text, seq_length):
    ids = encode(raw_text)
    data = []
    for i in range(0, len(ids) - seq_length):
        seq = ids[i:i+seq_length]
        target = ids[i+1:i+seq_length+1]
        data.append((seq, target))
    return data

print("Generating training sequences…")
sequences = make_sequences(raw_text, SEQ_LENGTH)
print(f"Total number of training samples: {len(sequences)}")

class TextDataset(Dataset):
    def __init__(self, sequences):
        self.sequences = sequences
    def __len__(self):
        return len(self.sequences)
    def __getitem__(self, idx):
        x, y = self.sequences[idx]
        return torch.tensor(x, dtype=torch.long), torch.tensor(y, dtype=torch.long)

train_dataset = TextDataset(sequences)
train_loader = DataLoader(train_dataset, batch_size=BATCH_SIZE, shuffle=True)

# ======== Modulated MultiHeadAttention =========
class ModulatedMultiHeadAttention(nn.Module):
    def __init__(self, embed_dim, num_heads, dropout=0.1):
        super().__init__()
        self.embed_dim = embed_dim
        self.num_heads = num_heads
        self.dropout = nn.Dropout(dropout)
        assert embed_dim % num_heads == 0
        self.head_dim = embed_dim // num_heads
        self.W_q = nn.Linear(embed_dim, embed_dim)
        self.W_k = nn.Linear(embed_dim, embed_dim)
        self.W_v = nn.Linear(embed_dim, embed_dim)
        self.out_proj = nn.Linear(embed_dim, embed_dim)

    def forward(self, x, plant_signals):
        if x.dim() == 2:
            x = x.unsqueeze(0)
        B, T, D = x.shape
        q = self.W_q(x).view(B, T, self.num_heads, self.head_dim).transpose(1,2)
        k = self.W_k(x).view(B, T, self.num_heads, self.head_dim).transpose(1,2)
        v = self.W_v(x).view(B, T, self.num_heads, self.head_dim).transpose(1,2)
        attn_scores = torch.matmul(q, k.transpose(-2, -1)) / (self.head_dim ** 0.5)

        # --- MODULATION ---
        dopamine = plant_signals['dopamine']
        serotonin = plant_signals['serotonin']
        cortisol = plant_signals['cortisol']
        oxytocin = plant_signals['oxytocin']

        attn_scores = attn_scores * dopamine
        attn_scores = attn_scores + (serotonin - 1.0)
        attn_scores = attn_scores + torch.randn_like(attn_scores) * (cortisol - 1.0)
        mean_scores = attn_scores.mean(dim=1, keepdim=True)  # [B,1,T,T]
        attn_scores = attn_scores * (1 - oxytocin) + mean_scores * oxytocin

        attn_weights = torch.softmax(attn_scores, dim=-1)
        attn_output = torch.matmul(attn_weights, v)
        attn_output = attn_output.transpose(1,2).contiguous().view(B, T, D)
        out = self.out_proj(attn_output)
        return out, attn_weights  

# ======== Plant Encoder Layer ========
class PlantTransformerEncoderLayer(nn.Module):
    def __init__(self, embed_dim, num_heads, ff_dim, dropout=0.1):
        super().__init__()
        self.self_attn = ModulatedMultiHeadAttention(embed_dim, num_heads, dropout)
        self.linear1 = nn.Linear(embed_dim, ff_dim)
        self.dropout = nn.Dropout(dropout)
        self.linear2 = nn.Linear(ff_dim, embed_dim)
        self.norm1 = nn.LayerNorm(embed_dim)
        self.norm2 = nn.LayerNorm(embed_dim)
        self.activation = nn.ReLU()

    def forward(self, src, plant_signals, return_attn=False): 
        src2, attn_weights = self.self_attn(src, plant_signals)
        src = src + self.dropout(src2)
        src = self.norm1(src)
        src2 = self.linear2(self.dropout(self.activation(self.linear1(src))))
        src = src + self.dropout(src2)
        src = self.norm2(src)
        if return_attn:
            return src, attn_weights
        return src, None

# ======== Positional Encoding ========
class PositionalEncoding(nn.Module):
    def __init__(self, d_model, dropout=0.1, max_len=5000):
        super().__init__()
        self.dropout = nn.Dropout(dropout)
        pe = torch.zeros(max_len, d_model)
        position = torch.arange(0, max_len, dtype=torch.float).unsqueeze(1)
        div_term = torch.exp(torch.arange(0, d_model, 2).float() * (-torch.log(torch.tensor(10000.0)) / d_model))
        pe[:, 0::2] = torch.sin(position * div_term)
        pe[:, 1::2] = torch.cos(position * div_term)
        pe = pe.unsqueeze(0)
        self.register_buffer('pe', pe)
    def forward(self, x):
        x = x + self.pe[:, :x.size(1), :]
        return self.dropout(x)

# ======== Plant Transformer Language Model ========
class PlantTransformerLM(nn.Module):
    def __init__(self, vocab_size, embed_dim, nhead, num_layers, ff_dim, dropout):
        super().__init__()
        self.embedding = nn.Embedding(vocab_size, embed_dim)
        self.pos_encoder = PositionalEncoding(embed_dim, dropout)
        self.layers = nn.ModuleList([
            PlantTransformerEncoderLayer(embed_dim, nhead, ff_dim, dropout)
            for _ in range(num_layers)
        ])
        self.fc_out = nn.Linear(embed_dim, vocab_size)

    def forward(self, src, plant_signals, return_attn_from_layer=None):
        x = self.embedding(src)
        x = self.pos_encoder(x)
        attn_weights = None
        for idx, layer in enumerate(self.layers):
            if return_attn_from_layer is not None and idx == return_attn_from_layer:
                x, attn_weights = layer(x, plant_signals, return_attn=True)
            else:
                x, _ = layer(x, plant_signals)
        logits = self.fc_out(x)
        if return_attn_from_layer is not None:
            return logits, attn_weights
        return logits

def save_model(model, path="transformer_lm.pth"):
    torch.save(model.state_dict(), path)

def load_model(model, path="transformer_lm.pth"):
    model.load_state_dict(torch.load(path, map_location=DEVICE))
    model.eval()

# ========== Training =============
model = PlantTransformerLM(
    vocab_size=VOCAB_SIZE,
    embed_dim=EMBED_DIM,
    nhead=NHEAD,
    num_layers=NUM_LAYERS,
    ff_dim=FF_DIM,
    dropout=DROPOUT
).to(DEVICE)

total_params = sum(p.numel() for p in model.parameters())
print(f"Total number of parameters: {total_params}")

optimizer = optim.Adam(model.parameters(), lr=LR)

if os.path.exists("transformer_lm.pth"):
    load_model(model, "transformer_lm.pth")
    optimizer.load_state_dict(torch.load("optimizer.pth"))
    print("Model and optimizer loaded — you can continue training!")
else:
    print("Starting training from scratch…")

if os.path.exists("training_state.json"):
    with open("training_state.json") as f:
        d = json.load(f)
        START_EPOCH = d.get("last_epoch", 0)
else:
    START_EPOCH = 0

print(f"Starting training from epoch {START_EPOCH+1}")

criterion = nn.CrossEntropyLoss(ignore_index=PAD_ID)

print("Start… " + datetime.now().strftime("%H:%M"))

TOTAL_EPOCHS = START_EPOCH + NUM_EPOCHS

for epoch in range(START_EPOCH, TOTAL_EPOCHS):
    epoch_start = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
    model.train()
    total_loss = 0
    n_batches = len(train_loader)
    for i, (batch_x, batch_y) in enumerate(train_loader): 
        batch_x = batch_x.to(DEVICE)
        batch_y = batch_y.to(DEVICE)
        optimizer.zero_grad()
        plant_signals = plant_network_sim()   # or plant_network_sim(dopamine="high", ...)
        logits = model(batch_x, plant_signals)
        loss = criterion(logits.view(-1, VOCAB_SIZE), batch_y.view(-1))
        loss.backward()
        optimizer.step()
        total_loss += loss.item()
        if (i+1) % max(1, n_batches // 50) == 0 or i+1 == n_batches:
            progress = int(50 * (i+1) / n_batches)
            bar = "●" * progress + "-" * (50 - progress)
            percent = 100 * (i+1) // n_batches
            print(f"\rEpoch {epoch+1}/{TOTAL_EPOCHS} | [{bar}] {percent}%", end="")
    print()
    avg_loss = total_loss / n_batches
    print(f"{epoch_start} | Epoch {epoch+1}/{TOTAL_EPOCHS} | Loss: {avg_loss:.4f}")
    with open("training_state.json", "w") as f:
        json.dump({"last_epoch": epoch + 1}, f)

# ========== Text generating ==========
def generate_text(model, seed, plant_signals=None, length=50, temperature=1.0, top_k=20):
    model.eval()
    with torch.no_grad():
        ids = encode(seed)
        input_ids = ids[:]
        input_tensor = torch.tensor([input_ids], dtype=torch.long).to(DEVICE)
        for _ in range(length):
            if input_tensor.size(1) > SEQ_LENGTH:
                input_tensor = input_tensor[:, -SEQ_LENGTH:]
            logits = model(input_tensor, plant_signals or plant_network_sim())
            logits = logits[0, -1, :] / temperature
            if top_k > 0:
                top_k_logits, top_k_indices = torch.topk(logits, top_k)
                probs = torch.softmax(top_k_logits, dim=0)
                next_token = top_k_indices[torch.multinomial(probs, 1)].item()
            else:
                probs = torch.softmax(logits, dim=0)
                next_token = torch.multinomial(probs, 1).item()
            input_tensor = torch.cat([input_tensor, torch.tensor([[next_token]], device=DEVICE)], dim=1)
            input_ids.append(next_token)
            if next_token == EOS_ID:
                break
        return decode(input_ids)

# ========== Vizualization of attention heatmap ==========
def plot_attention_heatmaps(attn_weights, input_tokens, layer_idx, seq_idx):
    n_heads = attn_weights.shape[1]
    for head in range(n_heads):
        plt.figure(figsize=(6,4))
        title = f"Attention | Layer {layer_idx} | Sequence {seq_idx} | Head {head}"
        plt.title(title)
        plt.imshow(attn_weights[0, head].cpu().numpy(), cmap="viridis")
        if len(input_tokens) <= 40:
            plt.xlabel("Key tokens")
            plt.ylabel("Query tokens")
            plt.xticks(range(len(input_tokens)), input_tokens, rotation=45, fontsize=8)
            plt.yticks(range(len(input_tokens)), input_tokens, fontsize=8)
        else:
            plt.xlabel("Key token index")
            plt.ylabel("Query token index")
        plt.colorbar()
        plt.tight_layout()
        plt.show()

# ========== Example of single-sequence generation and attention visualization ==========
seed_text = "user: Why is sky blue?\nModel: "
signals = plant_network_sim(dopamine="normal", serotonin="normal", cortisol="normal", oxytocin="neutral")
ids = encode(seed_text)
input_tensor = torch.tensor(ids, dtype=torch.long).to(DEVICE)
input_tensor = ensure_batch_tensor(input_tensor)

model.eval()
with torch.no_grad():
    logits, attn_weights = model(input_tensor, signals, return_attn_from_layer=0)

input_tokens = decode(ids).split()
plot_attention_heatmaps(attn_weights, input_tokens, layer_idx=0, seq_idx=0)

# ========== Batch inference:  ==========
batch_texts = [
    "user: Why is sky blue?\nModel: ",
    "user: What is AI?\nModel: ",
    "user: How are you?\nModel: ",
]
ids_list = [encode(t) for t in batch_texts]
tensor_list = [torch.tensor(ids, dtype=torch.long) for ids in ids_list]
input_tensor = torch.nn.utils.rnn.pad_sequence(
    tensor_list, batch_first=True, padding_value=PAD_ID
).to(DEVICE)

signals = plant_network_sim()
model.eval()
with torch.no_grad():
    logits, attn_weights = model(input_tensor, signals, return_attn_from_layer=0)

for seq_idx, ids in enumerate(ids_list):
    input_tokens = decode(ids).split()
    plot_attention_heatmaps(attn_weights[seq_idx:seq_idx+1], input_tokens, layer_idx=0, seq_idx=seq_idx)

# ========== Example of generation (single sequence): ==========
print("Test:")
print(generate_text(model, seed_text, plant_signals=signals, length=50, temperature=1.0, top_k=40))

save_model(model, "transformer_lm.pth")
torch.save(optimizer.state_dict(), "optimizer.pth")
